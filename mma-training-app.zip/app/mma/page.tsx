import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";

export default function MMAApp() {
  const [log, setLog] = useState("");
  const [workout, setWorkout] = useState("");
  const [trainingType, setTrainingType] = useState("striking");

  const workouts = {
    striking: [
      "5 rounds shadowboxing (orthodox/southpaw)",
      "Footwork drills: L-steps, pivots, pendulum",
      "Combo practice: jab-cross-hook, jab-slip-cross"
    ],
    wrestling: [
      "3 rounds sprawls + shots",
      "Wall resistance holds (30s x 3)",
      "Hip escapes, penetration steps"
    ],
    grappling: [
      "Triangle choke practice (3 sets)",
      "Bridging + shrimping (3 rounds)",
      "Technical standups"
    ],
    conditioning: [
      "Burpees x 15, Jump squats x 20, Pushups x 30",
      "Sprint intervals: 5x20m",
      "Plank holds: 3x1 min"
    ]
  };

  return (
    <div className="min-h-screen bg-black text-white p-4">
      <h1 className="text-3xl font-bold mb-4">MMA Training Hub</h1>

      <Tabs defaultValue="striking" onValueChange={(val) => setTrainingType(val)}>
        <TabsList className="mb-4">
          <TabsTrigger value="striking">Striking</TabsTrigger>
          <TabsTrigger value="wrestling">Wrestling</TabsTrigger>
          <TabsTrigger value="grappling">Grappling</TabsTrigger>
          <TabsTrigger value="conditioning">Conditioning</TabsTrigger>
        </TabsList>
        {Object.entries(workouts).map(([key, value]) => (
          <TabsContent value={key} key={key}>
            <Card className="bg-white text-black">
              <CardContent className="p-4">
                <ul className="list-disc pl-4">
                  {value.map((item, idx) => <li key={idx}>{item}</li>)}
                </ul>
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>

      <div className="mt-6">
        <h2 className="text-xl font-semibold mb-2">Training Log</h2>
        <Textarea 
          placeholder="What did you train today? How did it feel?"
          value={log}
          onChange={(e) => setLog(e.target.value)}
          className="bg-white text-black"
        />
        <Button className="mt-2" onClick={() => setLog("")}>Save Entry</Button>
      </div>
    </div>
  );
}
